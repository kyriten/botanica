<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        2025 &copy; Copyright <strong><span>{{ config('app.name') }}</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->
